let currentInput = "";

function appendValue(value) {
    currentInput += value;
    document.getElementById("result").value = currentInput;
}

function clearDisplay() {
    currentInput = "";
    document.getElementById("result").value = "";
}

function calculate() {
    try {
        let result = eval(currentInput);
        document.getElementById("result").value = result;
        currentInput = result.toString();
    } catch (error) {
        document.getElementById("result").value = "Error";
        currentInput = "";
    }
}

// let radians = (degrees * Math.PI) / 180;
function calculateTrigFunction(func) {
    try {
        let degrees = eval(currentInput); // Input assumed to be in degrees
        let radians = (degrees * Math.PI) / 180; // Convert degrees to radians
        let result;
        switch (func) {
            case 'sin':
                result = Math.sin(radians);
                break;
            case 'cos':
                result = Math.cos(radians);
                break;
            case 'tan':
                result = Math.tan(radians);
                break;
            default:
                result = "Invalid function";
        }
        document.getElementById("result").value = result;
        currentInput = result.toString();
    } catch (error) {
        document.getElementById("result").value = "Error";
        currentInput = "";
    }
}
