let currentSlideIndex = 1;

function openLightbox() {
    document.getElementById('lightbox').style.display = 'block';
    showSlide(currentSlideIndex);
}

function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
}

function changeSlide(n) {
    showSlide(currentSlideIndex += n);
}

function currentSlide(n) {
    showSlide(currentSlideIndex = n);
}

function showSlide(n) {
    const slides = document.getElementsByClassName('slide');
    const captions = document.getElementsByClassName('caption');
    
    if (n > slides.length) {
        currentSlideIndex = 1;
    }
    
    if (n < 1) {
        currentSlideIndex = slides.length;
    }
    
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = 'none';
    }
    
    for (let i = 0; i < captions.length; i++) {
        captions[i].style.display = 'none';
    }
    
    slides[currentSlideIndex - 1].style.display = 'block';
    captions[currentSlideIndex - 1].style.display = 'block';
}
