// Randomly change the background color of testimonials and quotes
const testimonials = document.querySelectorAll('.testimonial');
const quotes = document.querySelectorAll('.quote');

function getRandomColor() {
  const colors = ['#F39C12', '#E74C3C', '#3498DB', '#27AE60'];
  return colors[Math.floor(Math.random() * colors.length)];
}

testimonials.forEach(testimonial => {
  testimonial.style.backgroundColor = getRandomColor();
});

quotes.forEach(quote => {
  quote.style.backgroundColor = getRandomColor();
});
